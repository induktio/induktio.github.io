#!/usr/bin/python

##############################################
# SWAT 3 CMP audio to WAV decompression tool
##############################################
# 
# Usage: python cmpreader.py filename.cmp
#
# Converted WAV files are written to the 'output' directory.
# If the input directory has filename.log available, it will be used to test 
# the correctness of decoder output, e.g. the included test files.
#
# Author: induktio <admin@induktio.net>
#
# Last changed: 2016-08-26
#


import sys
import struct
import wave
import os
from collections import deque


class BitReader:
    def __init__(self, f):
        self.input = f
        self.bits = 0
        self.bcount = 0
        self.readbts = 0
        self.readcnt = 0
        try:
            self.check = open(f.name.replace('cmp','log'))
        except:
            print 'Log not found:', f.name
            self.check = False

    def readbit(self):
        if self.bcount == 0 :
            a = self.input.read(4)
            if (len(a) > 0):
                self.bits = struct.unpack('<i', a)[0]
            else:
                raise RuntimeError
            self.bcount = 32
        rv = ( self.bits >> (32-self.bcount) ) & 1
        self.bcount -= 1
        return rv
        
    def verify(self, n, v):
        if self.check:
            cn, cv = self.check.readline().split()
            assert(int(cn) == n)
            assert(int(cv) == v)

    def readbits(self, n):
        v = 0
        if (self.readbts % 32) + n > 32 and n < 32:
            n1 = 32 - self.readbts % 32
            n2 = n - n1
            i = 0
            while i < n1:
                v |= (self.readbit() << i)
                i += 1
            i = 0
            v <<= n2
            while i < n2:
                v |= (self.readbit() << i)
                i += 1
        else:
            i = 0
            while i < n:
                v |= (self.readbit() << i)
                i += 1
        
        if n < 32:
            self.verify(n, v)
            self.readcnt += 1
            self.readbts += n
        return v


file = sys.argv[1].replace('.cmp','')
r = BitReader(open(file+'.cmp', 'rb'))

r.readbits(64)
len_coded = r.readbits(32)
len_wav = r.readbits(32)
sampling_freq = r.readbits(32)
r.readbits(96)

cache = deque()
mov_sum = 0
cur_len = 0
border = 0
samples = 0
d1 = 0
d2 = 0
smp = 0
high = 0

if not os.access('output', os.R_OK):
    os.mkdir('output')
wavout = wave.open('output/%s.wav' % (file.split('/')[-1]), 'wb')
wavout.setparams((1, 2, sampling_freq, len_wav/2, 'NONE', 'not compressed'))
wavsamples = []


while samples < len_wav/2:
    border = r.readbits(1)
    z = r.readbits(cur_len)

    if border == 1 and z == 0:
        new_len = r.readbits(4)
        cur_len = new_len
        high = max(high, new_len)
    else:
        sign = 1
        if border: sign = -1
        d1 = z * sign
        d2 += d1
        smp += d2
        
        samples += 1
        drift = 0
        cache.append(smp)
        mov_sum += smp
        
        if samples > 4000:
            mov_sum -= cache.popleft()
            drift = int(mov_sum / 4000.0)
        
        wavsamples.append(struct.pack('h', max(-32768, min(32767, (smp-drift)<<5))))


wavout.writeframes(''.join(wavsamples))
wavout.close()

print 'cmp: %d wav: %d freq: %d longest: %d' % (len_coded, len_wav, sampling_freq, high)


